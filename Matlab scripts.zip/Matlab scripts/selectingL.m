% Parameters
Vo = 400; % Output voltage (V)
fs = 500e3; % Switching frequency (Hz)
delta_IL_percent = 0.6;

% Number of design points (user-defined)
num_design_points = 100;

% Design space (Vin, Po)
Vin_designs = linspace(10, 325, num_design_points);
Po_designs = linspace(240, 1200, num_design_points);

%no of points
pts= 100;
% Evaluation grid (high resolution)
Vin_eval = linspace(10, 325,pts);
Po_eval = linspace(240, 1200,pts);
[Vin_eval_grid, Po_eval_grid] = meshgrid(Vin_eval, Po_eval);

% Arrays to store max stress values and corresponding L
min_max_stress_map = zeros(num_design_points, num_design_points);
L_map = zeros(num_design_points, num_design_points);

for i = 1:num_design_points
    for j = 1:num_design_points
        Vin_base = Vin_designs(i);
        Po_base = Po_designs(j);

        % Calculate base parameters
        Iout_base = Po_base / Vo;
        D_base = 1 - Vin_base / Vo;
        delta_IL_base = delta_IL_percent * Iout_base;
        L_base = (Vin_base * D_base) / (fs * delta_IL_base);

        % Evaluate LI^2 stress across all evaluation points
        Iout_eval = Po_eval_grid / Vo;
        D_eval = 1 - Vin_eval_grid / Vo;
        delta_IL = (Vin_eval_grid .* D_eval) ./ (fs * L_base);
        IL_peak = Iout_eval + delta_IL ./ 2;

        IL_rms = sqrt(Iout_eval.^2 + (IL_peak.^2) / 12);
        stress_map = L_base * IL_peak .* IL_rms;

        % Store maximum stress for this L
        min_max_stress_map(i, j) = max(stress_map(:));
        L_map(i, j) = L_base;
    end
end

% Create design grid for plotting
[Vin_design_grid, Po_design_grid] = meshgrid(Vin_designs, Po_designs);

% Plot surface of maximum LI^2 stress
figure;
surf(Vin_design_grid, Po_design_grid, min_max_stress_map, 'EdgeColor', 'none');
title('Maximum LI^2 Stress vs Design Operating Points');
xlabel('Design Vin (V)'); ylabel('Design Po (W)'); zlabel('Max LI^2'); colorbar; view(2);

% Find optimal point
[min_val, idx] = min(min_max_stress_map(:));
[opt_i, opt_j] = ind2sub(size(min_max_stress_map), idx);
best_L = L_map(opt_i, opt_j);
best_design = [Vin_designs(opt_i), Po_designs(opt_j)];

% Print results
fprintf('Best Design Point: Vin = %.2f V, Po = %.2f W\n', best_design(1), best_design(2));
fprintf('Optimal Inductance L = %.2f uH\n', best_L * 1e6);
fprintf('Minimum of Max LI^2 = %.6f\n', min_val);
