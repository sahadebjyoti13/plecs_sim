clc; clear;

% === Parameters ===
fs = 500e3;              % Switching frequency (Hz)
T = 1/fs;                % Period (s)
Bmax = 0.2;              % Peak flux density (T)
DeltaB = 2 * Bmax;       % Peak-to-peak flux swing (T)

% Core material parameters (e.g., N87 ferrite)
k = 3.2e-3;
alpha = 1.46;
beta = 2.75;

% Converter voltages
Vin = (2*sqrt(2)/pi)*230;  % ≈208V from full-bridge diode
Vout = 400;
D = 1 - Vin/Vout;          % Duty cycle
L = 100e-6;                % Inductance (H)
IL_min = 4.5;              % Starting inductor current
IL_max = 5.5;              % Peak inductor current

% === Time discretization ===
N = 1000;
t = linspace(0, T, N);  % One switching cycle
dt = t(2) - t(1);

% === Triangular B(t) waveform ===
B = zeros(size(t));
half_N = floor(N/2);
B(1:half_N) = linspace(-Bmax, Bmax, half_N);
B(half_N+1:end) = linspace(Bmax, -Bmax, N - half_N);

% === Numerical derivative dB/dt ===
dB_dt = diff(B) / dt;
dB_dt(end+1) = dB_dt(end);  % pad to match length

% === IGSE integrand ===
IGSE_integrand = k * abs(dB_dt).^alpha * DeltaB^(beta - alpha);

% === Core loss calculation ===
P_core_density = sum(IGSE_integrand) * dt / T;

% === Optional: Total core loss ===
V_core = 2.5e-6;  % m^3
P_total = P_core_density * V_core;

% === Inductor current waveform (Triangular) ===
iL = zeros(size(t));
Ton = D * T;
Toff = T - Ton;
dIL_on = Vin / L;
dIL_off = (Vin - Vout) / L;
iL(1:half_N) = IL_min + dIL_on * t(1:half_N);                  % ramp up
iL(half_N+1:end) = IL_max + dIL_off * (t(half_N+1:end) - Ton); % ramp down

% === Output ===
fprintf('Vin = %.1f V, Vout = %.1f V, Duty Cycle D = %.3f\n', Vin, Vout, D);
fprintf('Core Loss Density: %.2f W/m^3\n', P_core_density);
fprintf('Total Core Loss: %.3f W (for %.1f cm^3 core)\n\n', P_total, V_core * 1e6);

% === Plotting ===
figure;

subplot(4,1,1);
plot(t*1e6, B, 'b', 'LineWidth', 1.5);
xlabel('Time (\mus)'); ylabel('B(t) [T]');
title('Flux Density B(t)');
grid on;

subplot(4,1,2);
plot(t*1e6, dB_dt, 'r', 'LineWidth', 1.5);
xlabel('Time (\mus)'); ylabel('dB/dt [T/s]');
title('Rate of Change of B(t)');
grid on;

subplot(4,1,3);
plot(t*1e6, IGSE_integrand, 'm', 'LineWidth', 1.5);
xlabel('Time (\mus)'); ylabel('IGSE [W/m^3]');
title('IGSE Instantaneous Core Loss');
grid on;

subplot(4,1,4);
plot(t*1e6, iL, 'g', 'LineWidth', 1.5);
xlabel('Time (\mus)'); ylabel('i_L(t) [A]');
title('Inductor Current i_L(t)');
grid on;


% Parameters
Vin = 207.1;        % Input voltage (V)
fs = 500e3;         % Switching frequency (Hz)
T = 1/fs;           % Switching period (s)
D = 0.482;          % Duty cycle
Ae = 40e-6;         % Core effective area (m^2)
N_values = 1:40;    % Range of turns to analyze

% Time vectors for one switching period
t_on = linspace(0, D*T, 1000);
t_off = linspace(D*T, T, 1000);

% Preallocate peak B vector
Bmax_vec = zeros(size(N_values));

% Calculate peak B for each N
for i = 1:length(N_values)
    N = N_values(i);
    % Flux change during ON time
    delta_phi = Vin * D * T;  % V * s
    % Peak flux density
    Bmax_vec(i) = delta_phi / (N * Ae);
end

% Select a specific N to plot B(t)
N_plot = 10;  % change this as needed

% Calculate B(t) waveform for selected N
% During ON time: flux increases linearly
B_on = (Vin/(N_plot*Ae)) * t_on;

% During OFF time: flux decreases linearly
V_L_off = Vin - (Vin/(1 - D));  % approx voltage during OFF, approx zero ideally
% Actually, voltage reverses, so flux falls at rate V_off/(N*Ae)
% For boost converter inductor voltage during OFF:
V_off = Vin - (Vin/(1-D));  % More accurate approx
% Simpler assumption: voltage reverses polarity and magnitude:
V_off = -Vin*(1-D)/D; % Alternative estimate to keep waveform triangular

B_off = B_on(end) + (V_off/(N_plot*Ae))*(t_off - D*T);

% Time vector for whole period
t = [t_on t_off];
B = [B_on B_off];

% Plot B(t) waveform for selected N
figure;
plot(t*1e6, B, 'LineWidth',1.5);
xlabel('Time (\mus)');
ylabel('Flux Density B (T)');
title(sprintf('Flux Density B(t) for N = %d turns', N_plot));
grid on;

% Plot Bmax vs N
figure;
plot(N_values, Bmax_vec, 'b-o','LineWidth',1.5);
xlabel('Number of Turns N');
ylabel('Peak Flux Density B_{max} (T)');
title('Peak Flux Density vs Number of Turns');
grid on;
