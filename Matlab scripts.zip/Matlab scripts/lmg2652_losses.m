function calculate_lmg2652_losses()
    %% Parameters (edit as needed)
    Vds_vals = [50, 100, 200, 300, 400];   % Switching node voltage [V]
    Iload_vals = [1, 2, 4, 6];             % Load current [A]
    fs = 500e3;                            % Switching frequency [Hz]

    % Device parameters from datasheet
    Rds_on = 0.14;         % On resistance [Ohm] at 25°C
    Coss = 34.2e-12;       % Output capacitance [F]
    ton = 40e-9;           % Turn-on delay time [s]
    toff = 45e-9;          % Turn-off delay time [s]

    %% Loop over all conditions
    [Vds_grid, Iload_grid] = meshgrid(Vds_vals, Iload_vals);
    Psw = zeros(size(Vds_grid));
    Pcoss = zeros(size(Vds_grid));
    Pcond = zeros(size(Vds_grid));
    Ptotal = zeros(size(Vds_grid));

    for i = 1:numel(Vds_grid)
        Vds = Vds_grid(i);
        I = Iload_grid(i);

        % Switching loss (turn-on/off)
        Psw(i) = 0.5 * Vds * I * (ton + toff) * fs;

        % Coss loss
        Pcoss(i) = 0.5 * Coss * Vds^2 * fs;

        % Conduction loss
        Pcond(i) = I^2 * Rds_on;

        % Total loss per FET
        Ptotal(i) = Psw(i) + Pcoss(i) + Pcond(i);
    end

    %% Display table of results
    fprintf(' Vds(V) | Iload(A) |  Psw(W)  |  Pcoss(W) | Pcond(W) | Total Loss (W)\n');
    fprintf('--------|----------|----------|-----------|----------|----------------\n');
    for i = 1:numel(Vds_grid)
        fprintf('%7.1f | %8.2f | %8.4f | %9.4f | %8.4f | %9.4f\n', ...
            Vds_grid(i), Iload_grid(i), Psw(i), Pcoss(i), Pcond(i), Ptotal(i));
    end

    %% Optional: 3D surface plot
    figure;
    surf(Vds_grid, Iload_grid, Ptotal);
    xlabel('V_{DS} [V]');
    ylabel('Load Current [A]');
    zlabel('Total Power Loss [W]');
    title('LMG2652 Total Loss vs V_{DS} and Load Current');
    colorbar;
    grid on;
end
