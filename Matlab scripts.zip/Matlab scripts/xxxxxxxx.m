clc; clear;

% Define symbolic variables
syms Vin Vo Po L eta fs real positive

% Boost converter duty cycle
D = 1 - Vin/Vo;

% Inductor current (avg, ripple, peak, rms)
IL_avg = Po / (eta * Vin);
delta_IL = Vin * D / (L * fs);
Ipk = IL_avg + delta_IL / 2;
Irms = sqrt(IL_avg^2 + delta_IL^2 / 12);

% Stress index expression
LIpkIrms = L * Ipk * Irms;

% First derivatives
dL_dVin = simplify(diff(LIpkIrms, Vin));
dL_dPo = simplify(diff(LIpkIrms, Po));

% Solve for critical points
crit_Vin_sym = simplify(solve(dL_dVin == 0, Vin, 'Real', true));
crit_Po_sym  = simplify(solve(dL_dPo  == 0, Po, 'Real', true));

% Second derivatives
d2L_dVin2 = simplify(diff(dL_dVin, Vin));
d2L_dPo2  = simplify(diff(dL_dPo, Po));

% Set known values
Vo_val = 400;
eta_val = 0.95;
fs_val = 500e3;
Po_val = 600;
Vin_val = 100;
L_val = 200e-6;

% -------------------
% === Check Vin side
% -------------------
disp("Checking d²(LIpkIrms)/dVin² at critical Vin:");

for k = 1:length(crit_Vin_sym)
    % First, fully substitute Vo and eta into crit_Vin_sym
    crit_Vin_eval = subs(crit_Vin_sym(k), [Vo, eta], [Vo_val, eta_val]);
    
    
    if ~isempty(symvar(crit_Vin_eval))
        fprintf("→ Skipping crit_Vin(%d) due to unresolved symbols.\n", k);
       continue;
   end

    crit_Vin_num = double(crit_Vin_eval);
    
    % Now evaluate the second derivative numerically
    d2_val = subs(d2L_dVin2, ...
        [Vo, eta, fs, Po, L, Vin], ...
        [Vo_val, eta_val, fs_val, Po_val, L_val, crit_Vin_num]);

    if ~isempty(symvar(d2_val))
        fprintf("→ Skipping due to unresolved symbols after substitution in d²(LIpkIrms)/dVin².\n");
        continue;
    end

    d2_num = double(d2_val);

    fprintf("→ At Vin = %.4f V, d²(LIpkIrms)/dVin² = %.6e\n", crit_Vin_num, d2_num);
    
    if d2_num > 0
        disp("   Local Minimum (Concave Up)");
    elseif d2_num < 0
        disp("   Local Maximum (Concave Down)");
    else
        disp("   Inconclusive (Second Derivative Zero)");
    end
end

% -------------------
% === Check Po side
% -------------------
disp("Checking d²(LIpkIrms)/dPo² at critical Po:");

for k = 1:length(crit_Po_sym)
    crit_Po_eval = subs(crit_Po_sym(k), [Vo, eta], [Vo_val, eta_val]);

    if ~isempty(symvar(crit_Po_eval))
        fprintf("→ Skipping crit_Po(%d) due to unresolved symbols.\n", k);
        continue;
    end

    crit_Po_num = double(crit_Po_eval);

    d2_val = subs(d2L_dPo2, ...
        [Vo, eta, fs, Vin, L, Po], ...
        [Vo_val, eta_val, fs_val, Vin_val, L_val, crit_Po_num]);

    if ~isempty(symvar(d2_val))
        fprintf("→ Skipping due to unresolved symbols after substitution in d²(LIpkIrms)/dPo².\n");
        continue;
    end

    d2_num = double(d2_val);

    fprintf("→ At Po = %.4f W, d²(LIpkIrms)/dPo² = %.6e\n", crit_Po_num, d2_num);

    if d2_num > 0
        disp("   Local Minimum (Concave Up)");
    elseif d2_num < 0
        disp("  Local Maximum (Concave Down)");
    else
        disp("  Inconclusive (Second Derivative Zero)");
    end
end
