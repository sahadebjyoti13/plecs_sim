% Fixed constants
Vin = 100;    % Input voltage (V)
Iout = 3;     % Output current (A)
fs = 500e3;   % Switching frequency (Hz)

% Sweep vectors
L_vals = logspace(-6, -3, 200);     % 1 uH to 1 mH
C_vals = logspace(-7, -3, 200);     % 0.1 uF to 1 mF
D_vals = linspace(0.1, 0.9, 200);   % Duty cycle

% Cases for overlays
D_cases = [0.3, 0.5, 0.7];
L_cases = [10e-6, 100e-6, 1e-3];    % 10 uH, 100 uH, 1 mH
C_cases = [1e-6, 100e-6, 1e-3];     % 1 uF, 100 uF, 1 mF

% ---------- PLOTS ----------

figure;

% ΔIL vs L for different D
subplot(2,2,1);
hold on;
for D = D_cases
    delta_IL = (Vin * D) ./ (fs .* L_vals);
    semilogx(L_vals * 1e6, delta_IL, 'LineWidth', 1.5, 'DisplayName', sprintf('D = %.1f', D));
end
xlabel('Inductance L (\muH)');
ylabel('\DeltaI_L (A)');
title('\DeltaI_L vs L');
legend;
grid on;

% ΔVc vs C for different D
subplot(2,2,2);
hold on;
for D = D_cases
    delta_Vc = (Iout * D) ./ (fs .* C_vals);
    semilogx(C_vals * 1e6, delta_Vc, 'LineWidth', 1.5, 'DisplayName', sprintf('D = %.1f', D));
end
xlabel('Capacitance C (\muF)');
ylabel('\DeltaV_C (V)');
title('\DeltaV_C vs C');
legend;
grid on;

% ΔIL vs D for different L
subplot(2,2,3);
hold on;
for L = L_cases
    delta_IL = (Vin .* D_vals) ./ (fs * L);
    plot(D_vals, delta_IL, 'LineWidth', 1.5, 'DisplayName', sprintf('L = %.0f\\muH', L*1e6));
end
xlabel('Duty Cycle D');
ylabel('\DeltaI_L (A)');
title('\DeltaI_L vs D');
legend;
grid on;

% ΔVc vs D for different C
subplot(2,2,4);
hold on;
for C = C_cases
    delta_Vc = (Iout .* D_vals) ./ (fs * C);
    plot(D_vals, delta_Vc, 'LineWidth', 1.5, 'DisplayName', sprintf('C = %.0f\\muF', C*1e6));
end
xlabel('Duty Cycle D');
ylabel('\DeltaV_C (V)');
title('\DeltaV_C vs D');
legend;
grid on;

sgtitle('Overlayed Ripple Characteristics in Boost Converter');
