Vo=400;
fs=500e3;
deltaIL_percent=0.6;
eta = 0.95

num = 100;
Vin_val=linspace(10,325,num);
Po_val=linspace(240,1200,num);

pts=100;
Vin_pts=linspace(10,325,pts);
Po_pts=linspace(240,1200,pts);
[Vin_grid,Po_grid]=meshgrid(Vin_pts,Po_pts)

for i = 1: length(Vin_grid)
    for j = 1: length(Po_grid)
        D_grid = 1-(Vin_grid(i)/Vo);
        Io_grid = Po_grid(j)/(eta.* Vin_grid(i));
        deltaIL_grid = Io_grid.*deltaIL_percent;
        L_grid = Vin_grid(i).*D_grid/(deltaIL_grid.*fs);
        IL_avg_grid = Io_grid / (1 - D_grid);
        IL_pk_grid = IL_avg_grid + (deltaIL_grid/2);
        stressIndex = L_grid*IL_pk_grid*IL_pk_grid;
        max_Stress = max(stressIndex(:));
        % Store the maximum stress value for the current iteration
        maxStressValues(i, j) = max_Stress;
    end
end
