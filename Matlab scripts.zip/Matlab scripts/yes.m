% Fixed parameters
Vo = 400;                % Output voltage (V)
fs = 500e3;              % Switching frequency (Hz)
delta_IL_percent = 0.6;

% Grid resolution
num_points = 100;

% Define operating range
Vin_range = linspace(10, 325, num_points);
Po_range = linspace(240, 1200, num_points);
[Vin_grid, Po_grid] = meshgrid(Vin_range, Po_range);

% Design points for L
Vin_designs = [10, 325];
Po_designs = [240, 1200];

% To store results
stress_maps = {};
max_stresses = [];
L_values = [];

for i = 1:length(Vin_designs)
    for j = 1:length(Po_designs)
        % Design point
        Vin_base = Vin_designs(i);
        Po_base = Po_designs(j);
        Iout_base = Po_base / Vo;
        D_base = 1 - Vin_base / Vo;
        delta_IL = delta_IL_percent * Iout_base;

        % Designed L
        L = (Vin_base * D_base) / (fs * delta_IL);

        % Stress index calculation over the grid
        Iout = Po_grid / Vo;
        D = 1 - Vin_grid / Vo;
        delta_IL_grid = (Vin_grid .* D) ./ (fs * L);
        ILpk = Iout + 0.5 * delta_IL_grid;
        ILrms = sqrt(Iout.^2 + (ILpk.^2)/12);
        LI2 = L * ILpk .* ILrms;

        % Store max LI^2
        max_stresses(end+1) = max(LI2(:));
        stress_maps{end+1} = LI2;
        L_values(end+1) = L;
    end
end

% Find the best design (min of max stress)
[~, idx] = min(max_stresses);
best_L = L_values(idx);
best_stress_map = stress_maps{idx};

% Plot the best stress map
figure;
surf(Vin_grid, Po_grid, best_stress_map, 'EdgeColor', 'none');
xlabel('Vin (V)'); ylabel('Po (W)'); zlabel('LI^2');
title(['Stress Map for Optimal L = ', num2str(best_L*1e6, '%.2f'), ' µH']);
colorbar; view(2);

% Print result
fprintf('✅ Best L = %.2f µH\n', best_L * 1e6);
fprintf('Minimum of maximum LI^2 across range = %.6f\n', max_stresses(idx));
% ----- Visualize All Stress Maps Side-by-Side -----
figure;
num_Ls = length(L_values);
cols = 2;
rows = ceil(num_Ls / cols);

for k = 1:num_Ls
    subplot(rows, cols, k);
    imagesc(Vin_range, Po_range, stress_maps{k});
    set(gca, 'YDir', 'normal');
    title(sprintf('L = %.2f µH\nMax LI^2 = %.6f', L_values(k)*1e6, max_stresses(k)));
    xlabel('Vin (V)');
    ylabel('Po (W)');
    colorbar;
end

sgtitle('Stress Maps for Different L Designs');
