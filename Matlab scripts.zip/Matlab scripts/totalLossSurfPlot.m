% Device Data: {Name, Vds, Rds(mΩ), Coss(pF), Qg(nC)}
devices = {
  'LMG3410R050', 600, 50, 89, 3.36;
  'LMG3422R030', 600, 30, 170, 3.5;
  'LMG3522R030', 650, 30, 235, 4.0;
  'LMG2652',     650, 140, 34.2, 2.5;
  'LMG3411R070', 600, 70, 71, 3.8;
};

% Assumptions
I_rms = 10; V_gs = 7.5; f_sw = 500e3;

names = devices(:,1);
Vds = cell2mat(devices(:,2));
Rds = cell2mat(devices(:,3)) * 1e-3;
Coss = cell2mat(devices(:,4)) * 1e-12;
Qg = cell2mat(devices(:,5)) * 1e-9;

P_cond = I_rms^2 .* Rds;
P_sw = 0.5 .* Coss .* Vds.^2 * f_sw;
P_gate = Qg .* V_gs * f_sw;
P_tot = P_cond + P_sw + P_gate;

% Plot
figure;
bar(categorical(names), [P_cond' P_sw' P_gate'], 'stacked');
legend('Conduction','Switching','Gate Drive','Location','northwest');
ylabel('Power Loss (W)');
title('GaN Loss Breakdown @10 A, 500 kHz, 7.5 Vgs');

% Display
fprintf('%-12s Cond\tSw\tGate\tTotal\n', 'Device');
for i = 1:length(names)
  fprintf('%-12s %.2f\t%.2f\t%.2f\t%.2f\n', names{i}, P_cond(i), P_sw(i), P_gate(i), P_tot(i));
end

% Constants from datasheet and assumptions
Rds_on = 70e-3;       % Ohm at 25°C
fsw = 500e3;          % Switching frequency in Hz
k_sw = 8e-6;          % Switching energy per amp in J
Vo = 400;             % Output voltage in V
eta = 0.95;           % Efficiency

% Generate 100-point sweeps for Vin and Pout
Vin_vals = linspace(10, 325, 100);
Pout_vals = linspace(240, 1200, 100);

% Create meshgrid
[Vin_grid, Pout_grid] = meshgrid(Vin_vals, Pout_vals);

% Initialize total loss matrix
Ptotal_grid = zeros(size(Vin_grid));

% Loop over all grid points
for i = 1:size(Vin_grid, 1)
    for j = 1:size(Vin_grid, 2)
        Vin = Vin_grid(i, j);
        Pout = Pout_grid(i, j);

        % Calculations
        Iin = Pout / (Vin * eta);
        D = 1 - Vin / Vo;
        Irms_L = Iin * sqrt(D);

        % Loss components
        Pcond_L = Irms_L^2 * Rds_on;
        Pcond_H = Iin^2 * Rds_on * (1 - D);
        Esw = k_sw * Iin;
        Psw_L = Esw * fsw;
        Psw_H = 0;  % ZVS for high-side

        % Total loss for both switches
        Ptotal = Pcond_L + Pcond_H + Psw_L;
        Ptotal_grid(i, j) = Ptotal;
    end
end

% Plot
figure;
surf(Vin_grid, Pout_grid, Ptotal_grid)
xlabel('Input Voltage V_{in} [V]')
ylabel('Output Power P_{out} [W]')
zlabel('Total Power Loss [W]')
title('Total Loss vs Input Voltage and Output Power (LMG3411R070)')
colorbar
shading interp
grid on
