% ==== Define Operating Point Grid ====
Vo = 400;                % Output voltage in V
fs = 500e3;              % Switching frequency in Hz
delta_IL_percent = 0.6;  % 60% current ripple

Vin_range = linspace(10, 325, 500);     % Input voltage range
Po_range = linspace(240, 1200, 500);    % Output power range

[Vin_grid, Po_grid] = meshgrid(Vin_range, Po_range);

% ==== Calculations ====
Iout_grid = Po_grid ./ Vo;             % Output current
D_grid = 1 - Vin_grid ./ Vo;           % Duty cycle
delta_IL_grid = delta_IL_percent .* Iout_grid;

L_grid = (Vin_grid .* D_grid) ./ (fs .* delta_IL_grid);  % Inductance in H
ILavg = Iout_grid./(1-D_grid);
ILpk_grid = ILavg+ delta_IL_grid / 2;

ILrms_grid = sqrt(ILavg.^2 + (delta_IL_grid.^2) / 12);

LI2_grid = L_grid .* ILpk_grid .* ILrms_grid;            % Stress index

% ==== Plot 1: Inductance Surface ====
figure;
surf(Vin_grid, Po_grid, L_grid * 1e6); % Convert to µH
xlabel('Input Voltage V_{in} (V)');
ylabel('Output Power P_o (W)');
zlabel('Inductance L (\muH)');
title('Inductance vs V_{in} and P_o');
colorbar;
shading interp;
grid on;
view(45, 30);

% ==== Plot 2: Stress Index Surface ====
figure;
surf(Vin_grid, Po_grid, LI2_grid);
xlabel('Input Voltage V_{in} (V)');
ylabel('Output Power P_o (W)');
zlabel('Stress Index L I_{pk} I_{rms} (H·A^2)');
title('Inductor Stress Index vs V_{in} and P_o');
colorbar;
shading interp;
grid on;
view(45, 30);
