% Constants
Rds_on = 70e-3;
fsw = 500e3;
k_sw = 12.2e-6;   % [J/A] total switching energy per amp (from datasheet: Eon + Eoff)
Vo = 400;
eta = 0.95;

% Define Vin and Pout ranges (5x4 = 20 combinations)
Vin_vals = linspace(10, 325, 5);       % [10, 88.75, 167.5, 246.25, 325]
Pout_vals = linspace(240, 1200, 4);    % [240, 560, 880, 1200]

% Header
fprintf(['%-7s %-8s %-8s %-7s %-10s %-12s %-12s %-10s %-10s %-12s\n'], ...
    'Vin[V]', 'Pout[W]', 'Iin[A]', 'D[-]', 'Irms_L[A]', ...
    'Pcond_L[W]', 'Pcond_H[W]', 'Psw_L[W]', 'Psw_H[W]', 'TotalLoss[W]');
fprintf(repmat('-', 1, 100)); fprintf('\n');

% Loop
for Vin = Vin_vals
    for Pout = Pout_vals
        Iin = Pout / (Vin * eta);
        D = 1 - Vin / Vo;
        Irms_L = Iin * sqrt(D);
        Pcond_L = Irms_L^2 * Rds_on;
        Pcond_H = Iin^2 * Rds_on * (1 - D);
        Psw_L = k_sw * Iin * fsw;
        Psw_H = 0;
        TotalLoss = Pcond_L + Pcond_H + Psw_L;

        % Print row
        fprintf('%-7.2f %-8.1f %-8.3f %-7.3f %-10.3f %-12.3f %-12.3f %-10.3f %-10.3f %-12.3f\n', ...
            Vin, Pout, Iin, D, Irms_L, Pcond_L, Pcond_H, Psw_L, Psw_H, TotalLoss);
    end
end
