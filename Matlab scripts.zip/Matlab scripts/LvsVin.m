% Define parameters
Vout = 400;   % Desired output voltage (V)
DeltaI = 1.8; % Estimated inductor ripple current (A)
fS = 500e3;   % Switching frequency (Hz)
Vin_min = 10;  % Minimum input voltage (V)
Vin_max = 325; % Maximum input voltage (V)
Vin = linspace(Vin_min, Vin_max, 200); % Generate input voltage range

% Calculate inductance L for each Vin
L = (Vin .* (Vout - Vin)) ./ (DeltaI .* fS .* Vout);

% Plot L vs Vin
figure;
plot(Vin, L, 'b', 'LineWidth', 2);
xlabel('Input Voltage (V)');
ylabel('Inductance (H)');
title('Inductor Selection vs Input Voltage for Boost Converter');
grid on;
