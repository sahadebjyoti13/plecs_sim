clc,clear;
% Fixed values
Vo = 400; % Output voltage (V)
fs = 500e3; % Switching frequency (Hz)
delta_IL_percentage = 0.6; % 60% ripple of Iout
delta_Vc_percentage = 0.005; % 0.5% ripple of Vo

Vin_list = [10, 325]; % Input voltages
Po_list = [240, 1200]; % Output power levels

nVin = length(Vin_list);
nPo = length(Po_list);

% Pre-allocate storage
results = struct();

index = 1;

for i = 1:nVin
    for j = 1:nPo
        Vin = Vin_list(i);
        Po = Po_list(j);
        Iout = Po / Vo;
        D = 1 - (Vin / Vo);

        delta_IL = delta_IL_percentage * Iout;
        delta_Vc = delta_Vc_percentage * Vo;

        % Calculate L and C
        L = (Vin * D) / (fs * delta_IL);
        C = (Iout * D) / (fs * delta_Vc);

        % Store results for this operating point
        results(index).Vin = Vin;
        results(index).Po = Po;
        results(index).Iout = Iout;
        results(index).D = D;
        results(index).delta_IL = delta_IL;
        results(index).delta_Vc = delta_Vc;
        results(index).L = L;
        results(index).C = C;

        % Now evaluate delta_IL and delta_Vc at other operating points using this L, C
        results(index).eval = [];

        for m = 1:nVin
            for n = 1:nPo
                Vin_test = Vin_list(m);
                Po_test = Po_list(n);
                Iout_test = Po_test / Vo;
                D_test = 1 - (Vin_test / Vo);

                delta_IL_test = (Vin_test * D_test) / (fs * L);
                delta_Vc_test = (Iout_test * D_test) / (fs * C);

                results(index).eval(end+1).Vin = Vin_test;
                results(index).eval(end).Po = Po_test;
                results(index).eval(end).D = D_test;
                results(index).eval(end).delta_IL = delta_IL_test;
                results(index).eval(end).delta_Vc = delta_Vc_test;
            end
        end

        index = index + 1;
    end
end

% Display results
for k = 1:length(results)
    fprintf('\n--- Base Operating Point: Vin = %g V, Po = %g W ---\n', results(k).Vin, results(k).Po);
    fprintf('  Calculated L = %.2e H, C = %.2e F\n', results(k).L, results(k).C);
    fprintf('  Original ΔIL = %.3f A, ΔVc = %.3f V\n', results(k).delta_IL, results(k).delta_Vc);
    
    fprintf('  -- Ripple at other operating points using this L & C:\n');
    for e = 1:length(results(k).eval)
        r = results(k).eval(e);
        fprintf('    Vin = %g V, Po = %g W --> ΔIL = %.3f A, ΔVc = %.3f V\n', ...
            r.Vin, r.Po, r.delta_IL, r.delta_Vc);
    end
end
