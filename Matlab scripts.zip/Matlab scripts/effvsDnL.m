% Parameters (fixed)
Vin = 207.1;        % Input voltage [V]
Vout = 400;         % Output voltage [V]
Pout = 600;         % Output power [W]
fs = 500e3;         % Switching frequency [Hz]
Rds_on = 0.14;      % MOSFET on-resistance [Ohm]
t_sw = 85e-9;       % Switching transition time [s]
Eoss = 3e-6;        % Coss loss per switch [J]

% Duty cycle sweep
D_vals = linspace(0.0, 1.0, 100);

% Inductance sweep (for second plot)
L_vals = logspace(-6, -4, 100);  % 1uH to 100uH

% Preallocate efficiency arrays
eta_vs_D = zeros(size(D_vals));
eta_vs_L = zeros(size(L_vals));

% Constants for current ripple calculation
% Calculate input current for fixed output power (assumed ideal efficiency initially)
Iout = Pout / Vout;

% --------- Efficiency vs Duty Cycle ---------
for i = 1:length(D_vals)
    D = D_vals(i);
    
    % Input current (account for power balance approx)
    Iin = Pout / (Vin * 0.95); % Assume 95% initial efficiency to start
    
    % Inductor ripple current (approx)
    % Delta I_L = (Vin * D) / (L * fs)
    % But here, we don't know L yet, so pick nominal L = 20uH for ripple calc
    L_nom = 20e-6; % 20 uH nominal inductance
    
    delta_IL = (Vin * D) / (L_nom * fs);
    
    % RMS current in low-side MOSFET assuming triangular ripple:
    Irms_L = sqrt(Iin^2 * D + (delta_IL^2 * D) / 3);
    
    % Low-side conduction loss
    Pcond_L = Irms_L^2 * Rds_on;
    
    % High-side conduction loss (approximate)
    Pcond_H = (Iin^2) * Rds_on * (1 - D);
    
    % Switching losses (simplified)
    Psw_dyn = 0.5 * Vout * Iin * t_sw * fs;
    Pcoss = Eoss * fs;
    
    Psw_L = Psw_dyn + Pcoss;
    Psw_H = Psw_dyn + Pcoss;
    
    % Total losses
    Ploss = Pcond_L + Pcond_H + Psw_L + Psw_H;
    
    % Efficiency
    eta_vs_D(i) = Pout / (Pout + Ploss);
end

% --------- Efficiency vs Inductance ---------
D_fixed = 0.5; % fix duty cycle for this plot
for i = 1:length(L_vals)
    L = L_vals(i);
    
    Iin = Pout / (Vin * 0.95); % Assume 95% initial efficiency
    
    delta_IL = (Vin * D_fixed) / (L * fs);
    
    Irms_L = sqrt(Iin^2 * D_fixed + (delta_IL^2 * D_fixed) / 3);
    
    Pcond_L = Irms_L^2 * Rds_on;
    Pcond_H = (Iin^2) * Rds_on * (1 - D_fixed);
    
    Psw_dyn = 0.5 * Vout * Iin * t_sw * fs;
    Pcoss = Eoss * fs;
    
    Psw_L = Psw_dyn + Pcoss;
    Psw_H = Psw_dyn + Pcoss;
    
    Ploss = Pcond_L + Pcond_H + Psw_L + Psw_H;
    
    eta_vs_L(i) = Pout / (Pout + Ploss);
end

% Plot efficiency vs D
figure;
plot(D_vals, eta_vs_D * 100, 'LineWidth', 2);
xlabel('Duty Cycle D');
ylabel('Efficiency (%)');
title('Efficiency vs Duty Cycle');
grid on;
ylim([80 100]);

% Plot efficiency vs L
figure;
semilogx(L_vals*1e6, eta_vs_L * 100, 'LineWidth', 2);
xlabel('Inductance L (\muH)');
ylabel('Efficiency (%)');
title(['Efficiency vs Inductance at D = ' num2str(D_fixed)]);
grid on;
ylim([80 100]);
