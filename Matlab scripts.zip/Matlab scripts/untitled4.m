% Assuming `result_table` is already generated from the previous script

% Unique L and C values (in H and F)
L_vals = unique(result_table.L_uH) * 1e-6;
C_vals = unique(result_table.C_uF) * 1e-6;

% Duty ratio range
D_vals = linspace(0.0, 1.0, 1000);
Vin_sample = 200; % Arbitrary mid-point Vin for sweep
fs = 500e3;
Vo = 400;
Iout = mean(result_table.Eval_Po ./ Vo); % Average Iout for estimation

% === Plot 1: Delta IL vs L for different D ===
figure;
subplot(2,2,1);
hold on;
for D = linspace(0.0,1.0,10)
    delta_IL = (Vin_sample * D) ./ (fs * L_vals);
    plot(L_vals*1e6, delta_IL, 'DisplayName', sprintf('D=%.2f', D));
end
xlabel('Inductance (µH)');
ylabel('ΔIL (A)');
title('ΔIL vs L for various D');
grid on; legend;

% === Plot 2: Delta IL vs D for different L ===
subplot(2,2,2);
hold on;
for L = [10e-6, 100e-6, 300e-6]
    delta_IL = (Vin_sample * D_vals) ./ (fs * L);
    plot(D_vals, delta_IL, 'DisplayName', sprintf('L=%.0fµH', L*1e6));
end
xlabel('Duty Ratio (D)');
ylabel('ΔIL (A)');
title('ΔIL vs D for various L');
grid on; legend;

% === Plot 3: Delta Vc vs C for different D ===
subplot(2,2,3);
hold on;
for D = [0.2, 0.5, 0.8]
    delta_Vc = (Iout * D) ./ (fs * C_vals);
    plot(C_vals*1e6, delta_Vc, 'DisplayName', sprintf('D=%.2f', D));
end
xlabel('Capacitance (µF)');
ylabel('ΔVc (V)');
title('ΔVc vs C for various D');
grid on; legend;

% === Plot 4: Delta Vc vs D for different C ===
subplot(2,2,4);
hold on;
for C = [0.1e-6, 1e-6, 3e-6]
    delta_Vc = (Iout * D_vals) ./ (fs * C);
    plot(D_vals, delta_Vc, 'DisplayName', sprintf('C=%.1fµF', C*1e6));
end
xlabel('Duty Ratio (D)');
ylabel('ΔVc (V)');
title('ΔVc vs D for various C');
grid on; legend;

% Adjust layout
sgtitle('Ripple Variation Analysis in Boost Converter');
