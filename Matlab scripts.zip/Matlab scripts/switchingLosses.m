% MATLAB Code to compute conduction and switching losses for synchronous boost converter
% using GaN FET (LMG2652) at 25°C, including Eoss (Coss loss)

% Parameters
Vin = [10, 100, 200, 325];           % Input voltages [V]
Pout = [240, 600, 900, 1200];        % Output powers [W]
Vout = 400;                          % Output voltage [V]
fs = 500e3;                          % Switching frequency [Hz]
Rds_on = 0.14;                       % On-resistance at 25°C [Ohm]
t_sw = 85e-9;                        % Switching transition time [s]
eta = 1;                          % Efficiency
Eoss = 3e-6;                         % Output capacitance energy loss per switch [J]

% Print header with units
fprintf('\n%-5s | %-5s | %-7s | %-6s | %-7s | %-9s | %-9s | %-7s | %-7s | %-8s | %-8s\n', ...
    'Vin[V]', 'Pout[W]', 'Iin[A]', 'D[-]', 'Irms[A]', ...
    'Pcond_L[W]', 'Pcond_H[W]', 'Psw_L[W]', 'Psw_H[W]', 'Ptot_L[W]', 'Ptot_H[W]');
fprintf('%s\n', repmat('-', 1, 100));

% Loop through operating points
for i = 1:length(Vin)
    for j = 1:length(Pout)
        vin = Vin(i);
        pout = Pout(j);

        % Calculations
        Iin = pout / (vin * eta);                    % Input current [A]
        D = 1 - vin / Vout;                          % Duty ratio [-]
        Irms = Iin * sqrt(D);                        % RMS current through low-side [A]
        Pcond_L = Irms^2 * Rds_on;                   % Low-side conduction loss [W]
        Pcond_H = (Iin^2) * Rds_on * (1 - D);         % High-side conduction loss [W]
        Psw_dyn = 0.5 * Vout * Iin * t_sw * fs;      % Dynamic switching loss [W]
        Pcoss = Eoss * fs;                           % Coss loss [W]

        % Total switching losses
        Psw_L = Psw_dyn + Pcoss;
        Psw_H = Psw_dyn + Pcoss;

        % Total losses
        Ptot_L = Pcond_L + Psw_L;
        Ptot_H = Pcond_H + Psw_H;

        % Print formatted row
        fprintf('%5.0f | %6.0f | %7.2f | %6.2f | %7.2f | %9.3f | %9.3f | %7.3f | %7.3f | %8.3f | %8.3f\n', ...
            vin, pout, Iin, D, Irms, Pcond_L, Pcond_H, Psw_L, Psw_H, Ptot_L, Ptot_H);
    end
end
