% Parameters
Vo = 400; % Output voltage (V)
fs = 500e3; % Switching frequency (Hz)
delta_IL_percent = 0.6;

% Define base operating points (Vin, Po)
base_points = [
    10, 240;
    10, 1200;
    325, 240;
    325, 1200;
    200,1200
];

% Define eval operating points (Vin, Po)
eval_points = [
    10, 1200;
    10, 240;
    325, 240;
    325, 1200;
    200,1200
];

num_base = size(base_points, 1);
num_eval = size(eval_points, 1);

% Pre-allocate results matrix with 8 columns
results = zeros(num_base * num_eval, 8); 
% Columns: Base_Vin, Base_Po, L_uH, Eval_Vin, Eval_Po, IL_peak_A, IL_rms_A, L_ILpk_ILrms

row = 1;
for b = 1:num_base
    Vin_base = base_points(b,1);
    Po_base = base_points(b,2);
    Iout_base = Po_base / Vo;
    D_base = 1 - Vin_base / Vo;
    delta_IL_base = delta_IL_percent * Iout_base;

    % Calculate L at base operating point (Henry)
    L_base = (Vin_base * D_base) / (fs * delta_IL_base);

    for e = 1:num_eval
        Vin_eval = eval_points(e,1);
        Po_eval = eval_points(e,2);
        Iout_eval = Po_eval / Vo;
        D_eval = 1 - Vin_eval / Vo;

        % Calculate inductor ripple current delta_IL at eval point (peak-to-peak)
        delta_IL_eval = (Vin_eval * D_eval) / (fs * L_base);
        
        %Average inductor current
        IL_avg = Iout_eval/(1-D_eval);

        % Peak inductor current (A)
        ILpk =  IL_avg  + delta_IL_eval / 2;

        % RMS inductor current (A)
        ILrms = sqrt( IL_avg ^2 + (delta_IL_eval^2) / 12);

        % Store the results row
        results(row, :) = [Vin_base, Po_base, L_base * 1e6, Vin_eval, Po_eval, ILpk, ILrms, L_base * ILpk * ILrms];
        row = row + 1;
    end
end

% Create a table with column names
T = array2table(results, ...
    'VariableNames', {'Base_Vin_V', 'Base_Po_W', 'L_uH', 'Eval_Vin_V', 'Eval_Po_W', 'IL_peak_A', 'IL_rms_A', 'L_ILpk_ILrms'});

disp(T);
