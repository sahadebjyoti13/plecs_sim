% Parameters
Vin_vals = [10, 325];
Po_vals = [240, 1200];
Vo = 400; % Output voltage (V)
fs = 500e3; % Switching frequency (Hz)
delta_IL_percent = 0.6;
delta_Vc_percent = 0.005;
% Initialize result table
results = [];
% Loop over base conditions
for Vin_base = Vin_vals
    for Po_base = Po_vals
        Iout_base = Po_base / Vo;
        D_base = 1 - Vin_base / Vo;
        delta_IL_base = delta_IL_percent * Iout_base;
        delta_Vc_spec = delta_Vc_percent * Vo;

        % Calculate L and C for base point
        L_base = (Vin_base * D_base) / (fs * delta_IL_base);
        C_base = (Iout_base * D_base) / (fs * delta_Vc_spec);
        % Loop over all eval conditions
        for Vin_eval = Vin_vals
            for Po_eval = Po_vals
                Iout_eval = Po_eval / Vo;
                D_eval = 1 - Vin_eval / Vo;

                % Recalculate ripple values using base L and C at eval point
                delta_IL_eval = (Vin_eval * D_eval) / (fs * L_base);
                delta_Vc_eval = (Iout_eval * D_eval) / (fs * C_base);

                % Store result row
                results = [results; 
                    Vin_base, Po_base, D_base, L_base*1e6, C_base*1e6, ...
                    Vin_eval, Po_eval, D_eval, delta_IL_eval, delta_Vc_eval];
            end
        end
    end
end

% Create table with headers
result_table = array2table(results, ...
    'VariableNames', {'Base_Vin', 'Base_Po', 'Base_D', 'L_uH', 'C_uF', ...
                      'Eval_Vin', 'Eval_Po', 'Eval_D', 'Delta_IL_A', 'Delta_Vc_V'});
% Display the table
disp(result_table);
