% Parameters
Vo = 400;              % Output voltage (V)
fs = 500e3;            % Switching frequency (Hz)
Vin_vals = linspace(10, 325, 50);        % Vin grid
Po_vals = linspace(240, 1200, 50);       % Po grid
[Vin_grid, Po_grid] = meshgrid(Vin_vals, Po_vals);

% Non-idealities
rdson = 20e-3;     % MOSFET Rds(on)
rL = 50e-3;        % Inductor ESR

% Load current
Iout_grid = Po_grid ./ Vo;

% Duty cycle (initial guess)
D_grid = 1 - Vin_grid ./ Vo;

% Candidate L values (100 from 5uH to 400uH)
L_candidates = linspace(5e-6, 400e-6, 100);

% Preallocate
max_stress_per_L = zeros(size(L_candidates));
stress_maps = cell(size(L_candidates));

% Iterate through candidate L values
for i = 1:length(L_candidates)
    L = L_candidates(i);

    % Estimate average inductor current ≈ output current / (1 - D)
    IL_avg = Iout_grid ./ (1 - D_grid);

    % Effective input voltage considering losses (clipped to avoid < 0)
    Vin_eff = max(Vin_grid - IL_avg * (rdson + rL), 1);  % min 1V to avoid invalid D

    % Corrected duty ratio based on Vin_eff (clipped to [0,1])
    D_eff = min(max(1 - Vin_eff ./ Vo, 0), 1);

    % Ripple current (delta_IL)
    delta_IL = (Vin_eff .* D_eff) ./ (fs * L);

    % IL_peak and IL_rms
    IL_pk = IL_avg + delta_IL / 2;
    IL_rms = sqrt(IL_avg.^2 + (delta_IL.^2) / 12);

    % Stress index (proxy for volume & thermal load)
    stress_index = L .* IL_pk .* IL_rms;

    % Store max stress and map
    max_stress_per_L(i) = max(stress_index(:));
    stress_maps{i} = stress_index;
end

% Find optimal L
[min_stress_val, best_L_index] = min(max_stress_per_L);
best_L = L_candidates(best_L_index);

% Plot optimal stress map
figure;
surf(Vin_grid, Po_grid, stress_maps{best_L_index}, 'EdgeColor', 'none');
xlabel('Vin (V)');
ylabel('Po (W)');
zlabel('Stress Index (L·Ipk·Irms)');
title(['Optimal L = ', num2str(best_L*1e6, '%.2f'), ' \muH with non-idealities']);
colorbar;
view(45, 30);

% Display result
fprintf('✔ Recommended Inductor Value: %.2f µH\n', best_L * 1e6);
% Plot: Max Stress vs. L
figure;
plot(L_candidates * 1e6, max_stress_per_L, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 4);
grid on;
xlabel('Inductance (µH)');
ylabel('Maximum Stress Index (L·Ipk·Irms)');
title('Worst-case Stress vs. Inductor Value');
xline(best_L * 1e6, '--r', ['Optimal L = ', num2str(best_L * 1e6, '%.2f'), ' µH']);
