% Constants from datasheet and assumptions
Rds_on = 70e-3;       % Ohm at 25°C
fsw = 500e3;          % Switching frequency in Hz
k_sw = 8e-6;          % Switching energy per amp in J
Vo = 400;             % Output voltage in V
eta = 0.95;           % Efficiency

% Generate 100-point sweeps for Vin and Pout
Vin_vals = linspace(10, 325, 100);
Pout_vals = linspace(240, 1200, 100);

% Create meshgrid
[Vin_grid, Pout_grid] = meshgrid(Vin_vals, Pout_vals);

% Initialize total loss matrix
Ptotal_grid = zeros(size(Vin_grid));

% Loop over all grid points
for i = 1:size(Vin_grid, 1)
    for j = 1:size(Vin_grid, 2)
        Vin = Vin_grid(i, j);
        Pout = Pout_grid(i, j);

        % Calculations
        Iin = Pout / (Vin * eta);
        D = 1 - Vin / Vo;
        Irms_L = Iin * sqrt(D);

        % Loss components
        Pcond_L = Irms_L^2 * Rds_on;
        Pcond_H = Iin^2 * Rds_on * (1 - D);
        Esw = k_sw * Iin;
        Psw_L = Esw * fsw;
        Psw_H = 0;  % ZVS for high-side

        % Total loss for both switches
        Ptotal = Pcond_L + Pcond_H + Psw_L;
        Ptotal_grid(i, j) = Ptotal;
    end
end

% Plot
figure;
surf(Vin_grid, Pout_grid, Ptotal_grid)
xlabel('Input Voltage V_{in} [V]')
ylabel('Output Power P_{out} [W]')
zlabel('Total Power Loss [W]')
title('Total Loss vs Input Voltage and Output Power (LMG3411R070)')
colorbar
shading interp
grid on
