syms Vin Po Vo fs L real

% Define constants
Vo_val = 400;       % Output voltage in Volts
fs_val = 500e3;     % Switching frequency in Hz
L_val = 5e-6;      % Inductance in Henry

% Duty cycle
D = 1 - Vin / Vo;

% Average and ripple current
A = Po / (Vo * (1 - D));       % Equivalent to Po / (Vo - Vin)
B = (Vin * D) / (fs * L);      % Inductor ripple current

% LI^2 stress expression
f = A + 0.5 * B;
g = sqrt(A^2 + (1/12) * B^2);
LI2 = L * f * g;

% Compute partial derivatives
dLI2_dVin = simplify(diff(LI2, Vin));
dLI2_dPo = simplify(diff(LI2, Po));

% Substitute constant values
d1 = subs(dLI2_dVin, [Vo, fs, L], [Vo_val, fs_val, L_val]);
d2 = subs(dLI2_dPo,  [Vo, fs, L], [Vo_val, fs_val, L_val]);

% Solve the system
[Vin_sol, Po_sol] = solve([d1 == 0, d2 == 0], [Vin, Po], 'Real', true);

% Display solution
disp('Critical point (Vin, Po) where gradient of LI^2 is zero:');
disp(['Vin = ', char(Vin_sol)]);
disp(['Po = ', char(Po_sol)]);
