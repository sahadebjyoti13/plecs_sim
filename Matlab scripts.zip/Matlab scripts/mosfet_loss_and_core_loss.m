% Parameters
fsw = 500e3;
Ts = 1/fsw;
f_ac = 50;
Vrms = 230;
Vpeak = sqrt(2) * Vrms;
Vo = 400;
Ae = 203e-6;
Ve = 102e-6;
N = 25;
L = 10.83e-6;
eta = 0.95;

% Steinmetz (N97)
k = 2.57;
alpha = 1.47;
beta = 2.87;

% FET parameters
Rds_on = 70e-3;
k_sw = 12.2e-6;

% Time vector (AC half-cycle)
t_ac_vec = linspace(0, 20e-3, 200);
core_loss_avg = zeros(size(t_ac_vec));
fet_loss_total = zeros(size(t_ac_vec));

Po = 1200;  % Output power (fixed)

for idx = 1:length(t_ac_vec)
    t_ac = t_ac_vec(idx);
    Vin_t = abs(Vpeak * sin(2*pi*f_ac*t_ac));
    if Vin_t < 10
        Vin_t = 10;
    end

    Iin = Po / (Vin_t * eta);
    D = 1 - Vin_t / Vo;
    Irms_L = Iin * sqrt(D);

    % --- FET Loss ---
    Pcond_L = Irms_L^2 * Rds_on;
    Pcond_H = Iin^2 * Rds_on * (1 - D);
    Psw_L = k_sw * Iin * fsw;
    fet_loss_total(idx) = Pcond_L + Pcond_H + Psw_L;

    % --- Core Loss ---
    t = linspace(0, Ts, 1000);
    v = zeros(size(t));
    v(t <= D*Ts) = Vin_t;            % Correct ON-time voltage
    v(t > D*Ts) = Vin_t - Vo;        % Correct OFF-time voltage

    B = cumtrapz(t, v) / (Ae * N);
    B = B - mean(B);
    dBdt = [diff(B)./diff(t), 0];
    deltaB = max(B) - min(B);

    p_core_density = k * abs(dBdt).^alpha .* deltaB.^(beta - alpha);
    p_core_total = p_core_density * Ve;
    core_loss_avg(idx) = mean(p_core_total);
end

% Plot
figure;
plot(t_ac_vec*1e3, fet_loss_total, 'r', 'LineWidth', 2); hold on;
plot(t_ac_vec*1e3, core_loss_avg, 'b', 'LineWidth', 2);
xlabel('AC Time [ms]');
ylabel('Loss [W]');
title('MOSFET and Core Loss vs Time (Accurate v_L)');
legend('MOSFET Total Loss', 'Core Loss', 'Location', 'northwest');
grid on;
