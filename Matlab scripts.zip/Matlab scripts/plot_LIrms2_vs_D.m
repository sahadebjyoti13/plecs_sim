function plot_LIrms2_vs_D()
    % Operating conditions
    Vin_vals = [10, 325, 10, 325, 200];
    Po_vals = [240, 240, 1200, 1200, 1200];
    Vo = 400;
    fs = 500e3;
    delta_IL_pct = 0.6;
    delta_Vc_pct = 0.005;

    D_vals = zeros(1, length(Vin_vals));
    LIrms2_vals = zeros(1, length(Vin_vals));

    for i = 1:length(Vin_vals)
        Vin = Vin_vals(i);
        Po = Po_vals(i);
        Iout = Po / Vo;
        D = 1 - Vin / Vo;
        D_vals(i) = D;

        % Optimization
        f = @(x) stress_ripple_objective(x, Vin, Vo, fs, Iout, D, delta_IL_pct, delta_Vc_pct);
        x0 = [100e-6, 5e-6];
        lb = [10e-6, 0.5e-6];
        ub = [500e-6, 50e-6];

        options = optimset('Display', 'off');
        [x_opt, ~] = fmincon(f, x0, [], [], [], [], lb, ub, [], options);

        % Calculate stress index = L * Irms^2
        L = x_opt(1);
        deltaIL = (Vin * D) / (fs * L);
        ILavg = Iout / (1 - D);
        Irms = sqrt(ILavg^2 + deltaIL^2 / 12);
        LIrms2_vals(i) = L * Irms^2;
    end

    % Plot
    figure;
    plot(D_vals, LIrms2_vals, 's-', 'LineWidth', 2, 'MarkerSize', 8);
    grid on;
    xlabel('Duty Ratio (D)', 'FontSize', 12);
    ylabel('L × I_{rms}^2 (W·s)', 'FontSize', 12);
    title('Inductor Power Stress vs Duty Ratio', 'FontWeight', 'bold');
end

function cost = stress_ripple_objective(x, Vin, Vo, fs, Iout, D, delta_IL_pct, delta_Vc_pct)
    L = x(1);
    C = x(2);
    deltaIL = (Vin * D) / (fs * L);
    deltaVc = Iout * D / (fs * C);
    ILavg = Iout / (1 - D);
    Ipk = ILavg + deltaIL / 2;
    Irms = sqrt(ILavg^2 + (deltaIL^2) / 12);
    stressIndex = L * Ipk * Irms;

    deltaIL_target = delta_IL_pct * Iout;
    deltaVc_target = delta_Vc_pct * Vo;
    ripple_penalty = ((deltaIL - deltaIL_target)/deltaIL_target)^2 + ((deltaVc - deltaVc_target)/deltaVc_target)^2;

    cost = stressIndex * (1 + ripple_penalty);
end
