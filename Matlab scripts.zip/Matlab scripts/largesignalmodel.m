% Parameters
Vo = 400;                % Output voltage (V)
L = 111.1e-6;              % Inductance (H)
C = 3e-6;              % Capacitance (F)

% Corner cases
Vin_vals = [10, 325];    % Input voltage range (V)
Po_vals = [1200, 240];   % Output power range (W)

figure;
hold on;
legendEntries = {};

for Vin = Vin_vals
    for Po = Po_vals
        % Calculate dependent parameters
        D = 1 - Vin / Vo;               % Duty cycle
        R = Vo^2 / Po;                  % Load resistance
        IL = Po / Vin;                  % Inductor current

        % Transfer function numerator and denominator
        num = [Vo, IL / (R * C)];
        den = [L * C, L / R, (1 - D)^2];

        % Transfer function Gid(s) = (Vo*s + IL/RC) / (LC*s^2 + L/R*s + (1-D)^2)
        sys = tf(num, den);

        % Plot Bode
        bode(sys, {1e2, 1e6}); grid on;
        legendEntries{end+1} = sprintf('Vin=%dV, Po=%.2fW', Vin, Po);
    end
end

title('Control-to-Inductor Current Transfer Function G_{id}(s)');
legend(legendEntries);
