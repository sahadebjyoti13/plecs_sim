function [c, ceq] = pfc_constraints(x)
    % Unpack variables
    gamma = x(1);
    N = round(x(2));
    Ae = x(3);

    % System params
    P_out = 1200; V_in_rms = 230; V_out = 400; f_sw = 500e3;
    I_in_rms = P_out / (V_in_rms * 0.95);
    I_in_pk = I_in_rms * sqrt(2);
    Delta_I = gamma * I_in_pk; 
    
    V_in_pk = V_in_rms * sqrt(2);
    L_req = (V_in_pk * (V_out - V_in_pk)) / (V_out * f_sw * Delta_I);

    % 1. Core Saturation Constraint
    % B_max must be less than B_sat (e.g., 0.3T for HF Ferrite at 100C)
    B_sat = 0.3;
    B_max = (L_req * (I_in_pk + 0.5 * Delta_I)) / (N * Ae);
    c(1) = B_max - B_sat; % B_max <= B_sat
    
    % 2. Window Fill Factor / Current Density Constraint
    % Ensure the wire doesn't overheat
    J_max = 5e6; % Max current density 5 A/mm^2 (5e6 A/m^2)
    Window_Area = 1.5 * Ae; 
    kw = 0.4; % Litz wire fill factor
    A_wire_total = kw * Window_Area;
    A_wire_per_turn = A_wire_total / N;
    
    % Calculate required area based on RMS current
    I_rms_ind = I_in_rms * sqrt(1 + (gamma^2)/12);
    A_wire_req = I_rms_ind / J_max;
    
    % Required wire area must be less than available wire area per turn
    c(2) = A_wire_req - A_wire_per_turn; 
    
    % 3. Manufacturability (Air Gap Constraint)
    % The required air gap must be positive and physically reasonable (< 5mm)
    mu0 = 4 * pi * 1e-7;
    mu_r = 1500;
    le = 8 * sqrt(Ae);
    lg_calc = (mu0 * N^2 * Ae / L_req) - (le / mu_r);
    
    c(3) = -lg_calc;           % lg must be > 0 (can't have negative gap)
    c(4) = lg_calc - 5e-3;     % lg must be < 5mm
    
    ceq = [];
end