function objectives = pfc_objectives(x)
    % Unpack variables
    gamma = x(1); 
    N = round(x(2)); 
    Ae = x(3);    

    % --- Fixed System Parameters ---
    P_out = 1200;      
    V_in_rms = 230;    
    V_out = 400;       
    f_sw = 500e3;      
    efficiency_est = 0.97;
    
    % --- Current & Inductance Calculations ---
    V_in_pk = V_in_rms * sqrt(2);
    I_in_rms = P_out / (V_in_rms * efficiency_est);
    I_in_pk = I_in_rms * sqrt(2);
    
    Delta_I = gamma * I_in_pk; 
    I_rms_ind = I_in_rms * sqrt(1 + (gamma^2)/12); % RMS current in inductor
    
    % Required Inductance
    L_req = (V_in_pk * (V_out - V_in_pk)) / (V_out * f_sw * Delta_I);

    % --- Geometry & Volume Estimation ---
    % Assume EE or PQ type generic core relationships
    l_e = 8 * sqrt(Ae);         % Mean magnetic path length (m)
    V_core = Ae * l_e;          % Core volume (m^3)
    Window_Area = 1.5 * Ae;     % Winding window area (m^2)
    V_wind = Window_Area * 4 * sqrt(Ae); % Winding volume (m^3)
    Total_Volume = V_core + V_wind;

    % --- Inductor Losses ---
    
    % 1. Core Loss (Using High Frequency Ferrite params, e.g., TDK N49)
    % Steinmetz: P_core = k * f^alpha * B^beta  (Standard SI units)
    k_stein = 0.045; 
    alpha = 1.6; 
    beta = 2.5; 
    
    % Peak-to-Peak Flux Density Swing
    Delta_B = (L_req * Delta_I) / (N * Ae);
    B_ac = Delta_B / 2; % Amplitude for Steinmetz
    
    % Core loss in W/m^3 (Ensure f is in Hz, B in Tesla)
    P_core_density = k_stein * (f_sw)^alpha * (B_ac)^beta; 
    P_core = P_core_density * V_core;
    
    % 2. Copper Loss 
    % Assuming Litz wire, tightly packed to fill factor kw = 0.4
    kw = 0.4;
    rho_cu = 1.72e-8;
    MLT = 4 * sqrt(Ae); % Mean length per turn
    
    A_wire_total = kw * Window_Area;
    A_wire_per_turn = A_wire_total / N;
    
    R_dc = rho_cu * (N * MLT) / A_wire_per_turn;
    
    % AC Resistance factor for 500kHz Litz wire (estimated)
    % A well-designed Litz wire at 500kHz might have an R_ac/R_dc of 1.2 to 1.5
    F_R = 1.3; 
    R_ac = R_dc * F_R;
    
    P_cu = (I_rms_ind^2) * R_ac;

    % Total Loss
    Total_Loss = P_core + P_cu;

    % --- Return Objectives ---
    % Minimize Volume and Minimize Loss
    objectives = [Total_Volume, Total_Loss];
end