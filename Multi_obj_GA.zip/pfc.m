% pfc.m
clear; clc; close all;

% --- Optimization Variables ---
% x(1) = Ripple ratio (gamma = Delta I / I_pk)
% x(2) = Number of turns (N), MUST BE INTEGER
% x(3) = Core cross-sectional area Ae (m^2)

% Lower and Upper Bounds
lb = [0.1,  5,  20e-6]; 
ub = [1.0, 60, 300e-6];

% MOGA Options (N is variable 2, so IntCon = 2)
options = optimoptions('gamultiobj', ...
    'PopulationSize', 150, ...
    'ParetoFraction', 0.35, ...
    'MaxGenerations', 150, ...
    'Display', 'iter', ...
    'PlotFcn', @gaplotpareto);

% Run MOGA
disp('Starting MOGA Optimization for 500 kHz PFC Inductor...');
[x_opt, fval] = gamultiobj(@pfc_objectives, 3, [], [], [], [], lb, ub, @pfc_constraints, 2, options);

% --- Extract Results ---
Volumes_cm3 = fval(:,1) * 1e6; % Convert m^3 to cm^3
Losses_W = fval(:,2);

% --- AUTOMATED KNEE POINT FINDER (Normalized Distance Method) ---
disp('Calculating Optimal Knee Point...');
% Normalize objectives to a 0-1 scale
V_norm = (Volumes_cm3 - min(Volumes_cm3)) / (max(Volumes_cm3) - min(Volumes_cm3));
L_norm = (Losses_W - min(Losses_W)) / (max(Losses_W) - min(Losses_W));

% Find the point closest to the ideal origin (0,0)
distances = sqrt(V_norm.^2 + L_norm.^2);
[~, knee_idx] = min(distances);

% Extract Optimal Variables
optimal_x = x_opt(knee_idx, :);
gamma_opt = optimal_x(1);
N_opt = round(optimal_x(2));
Ae_opt = optimal_x(3);

% Plot the Pareto Front
figure('Name', 'Pareto Optimization');
scatter(Volumes_cm3, Losses_W, 'filled', 'MarkerFaceColor', 'b');
hold on;
plot(Volumes_cm3(knee_idx), Losses_W(knee_idx), 'rp', 'MarkerSize', 15, 'MarkerFaceColor', 'r');
xlabel('Inductor Volume (cm^3)');
ylabel('Total System Loss (W)');
title('Pareto Front: Volume vs. Efficiency (500 kHz PFC)');
legend('Pareto Solutions', 'Optimal Knee Point');
grid on; hold off;

% --- Save Results ---
save('pareto_results.mat', 'x_opt', 'fval');

% --- CALCULATE FINAL ENGINEERING BLUEPRINT ---
% Recalculating electrical parameters to get exact L and Gap
V_in_rms = 230; V_out = 400; P_out = 1200; f_sw = 500e3;
V_in_pk = V_in_rms * sqrt(2);
I_in_rms = P_out / (V_in_rms * 0.95);
I_in_pk = I_in_rms * sqrt(2);

Delta_I = gamma_opt * I_in_pk;
L_opt = (V_in_pk * (V_out - V_in_pk)) / (V_out * f_sw * Delta_I);

% Air Gap Calculation (Approximate Reluctance Model)
mu0 = 4 * pi * 1e-7;
mu_r = 1500; % Typical High-Freq Ferrite permeability
le_opt = 8 * sqrt(Ae_opt); % Geometric path length approximation
lg_opt = (mu0 * N_opt^2 * Ae_opt / L_opt) - (le_opt / mu_r);

% --- PRINT FINAL BLUEPRINT ---
fprintf('\n======================================================\n');
fprintf('           FINAL OPTIMAL INDUCTOR DESIGN              \n');
fprintf('======================================================\n');
fprintf('  --- Design Variables Found by MOGA ---\n');
fprintf('  Ripple Ratio (r):     %.2f (%.1f%% Ripple)\n', gamma_opt, gamma_opt*100);
fprintf('  Number of Turns (N):  %d\n', N_opt);
fprintf('  Core Area (Ae):       %.2f mm^2\n', Ae_opt * 1e6);
fprintf('\n  --- Target Component Values to Build/Buy ---\n');
fprintf('  Required Inductance:  %.2f uH\n', L_opt * 1e6);
fprintf('  Required Air Gap:     %.2f mm\n', lg_opt * 1e3);
fprintf('\n  --- Performance Metrics ---\n');
fprintf('  Total Volume:         %.2f cm^3\n', Volumes_cm3(knee_idx));
fprintf('  Total Power Loss:     %.2f W\n', Losses_W(knee_idx));
fprintf('======================================================\n');